import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  emp: Employee = {
    empId: 0, empName: '', empPAN: '', empDesg: '', empDomain: '',
    empDOJ: null, empDOB: null, empSal: 0., empMail: '', empPassword: ''
  };
  constructor(private empService: EmployeeService, private route: Router) { }
  ngOnInit() {
    this.emp = this.empService.fetchInitialEmployeeDetails();
  }
  updateEmployee() {
    this.empService.update(this.emp).subscribe(
      success => alert('Update Successful'),
      error => alert(error)
    );
    this.route.navigate(['']);
  }
  compare() {
    if (this.emp.empDOB > this.emp.empDOJ) {
      alert('Dates are not in proper order');
      this.emp.empDOB = null;
      this.emp.empDOJ = null;
    }
  }
}
