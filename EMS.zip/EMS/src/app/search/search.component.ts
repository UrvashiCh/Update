import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  emp: number;
  result: Employee;
  constructor(private empService: EmployeeService, private route: Router) { }
  ngOnInit() {
  }
  sendSearchRequest(): void {
    this.empService.findEmployees(this.emp).subscribe((data: Employee) => {
      this.result = data;
      //console.log(this.result);
      this.empService.setEmpDetail(this.result);
      this.route.navigate(['update']);
    }, error => { alert('No Records Found for the given Employee Id'); });
  }
}
