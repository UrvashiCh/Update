package com.cg.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.model.Employee;
import com.cg.ems.repo.EmsDAO;

@RestController
@RequestMapping(value="/api")
@CrossOrigin(origins = "http://localhost:4200")
public class EMSController {
	
	@Autowired
	EmsDAO emsDao;
	
	@GetMapping(value="/search/{id}")
	public Employee search(@PathVariable("id") int id) {
		return emsDao.findById(id).get();
	}
	
	@PutMapping(value="/modify")
	public int update(@RequestBody Employee emp) {
		emsDao.save(emp);
		return 1;
	}
}
