package com.cg.ems.repo;


import com.cg.ems.model.Employee;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmsDAO extends CrudRepository<Employee, Integer> {
	
}
